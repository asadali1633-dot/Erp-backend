


const generateUniqueBarcode = async (req, res) => {
    try {
        const db = req.db;
        const [result] = await db.query(
            `SELECT asset_tag FROM assets 
             WHERE asset_tag REGEXP '^[0-9]{6}$' 
             ORDER BY CAST(asset_tag AS UNSIGNED) DESC 
             LIMIT 1`
        );

        let nextNumber = 1;
        if (result.length > 0) {
            const lastBarcode = parseInt(result[0].asset_tag, 10);
            nextNumber = lastBarcode + 1;
            if (nextNumber > 999999) {
                return res.status(400).json({
                    success: false,
                    message: 'Maximum barcode limit reached (999999)'
                });
            }
        }
        const barcode = nextNumber.toString().padStart(6, '0');
        const [existing] = await db.query(
            'SELECT id FROM assets WHERE asset_tag = ?',
            [barcode]
        );

        if (existing.length > 0) {
            const timestamp = Date.now().toString().slice(-6);
            return res.json({
                success: true,
                data: {
                    barcode: timestamp,
                    number: timestamp,
                    note: 'Used timestamp as fallback'
                }
            });
        }
        res.json({
            success: true,
            data: {
                barcode: barcode,
                number: barcode,
                sequence: nextNumber
            }
        });

    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

const createAssets = async (req, res) => {
    try {
        const db = req.db;
        const created_by = req.user.id;
        const {
            asset_tag,
            asset_type,
            assign_to,
            field_values,
        } = req.body;

        if (!asset_tag) {
            return res.status(400).json({
                success: false,
                message: 'Required fields: asset_tag, name'
            });
        }

        const [existing] = await db.query(
            'SELECT id FROM assets WHERE asset_tag = ?',
            [asset_tag]
        );

        if (existing.length > 0) {
            return res.status(400).json({
                success: false,
                message: 'Asset tag already exists'
            });
        }

        const [category] = await db.query(
            'SELECT id, name, fields_definition FROM asset_categories WHERE name = ?',
            [asset_type]
        );

        if (category.length === 0) {
            return res.status(400).json({
                success: false,
                message: `${asset_type} category not found in database`
            });
        }

        const uploadedFiles = [];
        if (req.files && req.files.length > 0) {
            req.files.forEach(file => {
                const fileInfo = {
                    filename: file.filename,
                    originalName: file.originalname,
                    path: file.path,
                    size: file.size,
                    mimetype: file.mimetype,
                    url: `/uploads/assets/${req.file.filename}`
                };
                uploadedFiles.push(fileInfo);
            });
        } else if (req.file) {
            const fileInfo = {
                filename: req.file.filename,
                originalName: req.file.originalname,
                path: req.file.path,
                size: req.file.size,
                mimetype: req.file.mimetype,
                url: `/uploads/assets/${req.file.filename}`
            };
            uploadedFiles.push(fileInfo);
        }

        if (uploadedFiles.length > 0) {
            parsedFieldValues.attachments = uploadedFiles;
            parsedFieldValues.has_attachments = true;
            parsedFieldValues.attachment_count = uploadedFiles.length;
        }

        let assigned_to_emp_id = null;
        let assigned_to_admin_id = null;
        let assignmentError = null;

        if (assign_to) {
            const [employee] = await db.query(
                'SELECT id, first_name, last_name FROM employee_info WHERE id = ?',
                [assign_to]
            );

            if (employee.length > 0) {
                assigned_to_emp_id = assign_to;
            } else {
                const [admin] = await db.query(
                    'SELECT id, first_name, last_name FROM super_admin WHERE id = ?',
                    [assign_to]
                );

                if (admin.length > 0) {
                    assigned_to_admin_id = assign_to;
                } else {
                    assignmentError = `User with ID ${assign_to} not found in employee or super admin records`;
                }
            }
        }

        const category_id = category[0].id;

        const [result] = await db.query(
            `INSERT INTO assets 
            (asset_tag, category_id, name, field_values,assigned_to_emp_id, assigned_to_admin_id) 
            VALUES (?, ?, ?, ?, ?, ?)`,
            [
                asset_tag,
                category_id,
                asset_type,
                JSON.stringify(field_values || {}),
                assigned_to_emp_id,
                assigned_to_admin_id
            ]
        );

        const [assets] = await db.query(
            `SELECT a.*, ac.name as category_name 
             FROM assets a
             JOIN asset_categories ac ON a.category_id = ac.id
             WHERE a.id = ?`,
            [result.insertId]
        );

        if (assets[0].field_values) {
            assets[0].field_values = JSON.parse(assets[0].field_values);
        }

        res.status(201).json({
            success: true,
            message: `${asset_type} created successfully`,
            data: {
                id: assets[0].id,
                asset_tag: assets[0].asset_tag,
                type: asset_type,
                name: assets[0].name,
                status: assets[0].status,
                details: assets[0].field_values,
                created_at: assets[0].created_at
            }
        });

    } catch (error) {
        console.error('Error creating laptop:', error);
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

const getAllAssets = async (req, res) => {
    try {
        const db = req.db;

        const [assets] = await db.query(`
            SELECT 
                a.*, 
                ac.name as category_name,
                e.id as employee_id,
                CONCAT(e.first_name, ' ', e.last_name) as employee_name,
                e.email as employee_email,
                sa.id as super_admin_id,
                CONCAT(sa.first_name, ' ', sa.last_name) as super_admin_name,
                sa.email as super_admin_email
            FROM assets a
            JOIN asset_categories ac ON a.category_id = ac.id
            LEFT JOIN employee_info e ON a.assigned_to_emp_id = e.id
            LEFT JOIN super_admin sa ON a.assigned_to_admin_id = sa.id
            ORDER BY a.created_at DESC
        `);

        assets.forEach(asset => {
            if (asset.field_values && typeof asset.field_values === 'string') {
                try {
                    asset.field_values = JSON.parse(asset.field_values);
                } catch (e) {
                    asset.field_values = {};
                }
            }
        });

        res.json({
            success: true,
            count: assets.length,
            data: assets
        });

    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};

const getAssetById = async (req, res) => {
    try {
        const db = req.db;
        const { id } = req.params;

        if (!id || isNaN(id)) {
            return res.status(400).json({
                success: false,
                message: 'Invalid asset ID'
            });
        }

        // Simple query - sirf basic info
        const [assets] = await db.query(`
            SELECT 
                a.*, 
                ac.name as category_name
            FROM assets a
            JOIN asset_categories ac ON a.category_id = ac.id
            WHERE a.id = ?`, id);

        if (assets.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Asset not found'
            });
        }

        const asset = assets[0];

        let fieldValues = {};
        if (asset.field_values && typeof asset.field_values === 'string') {
            try {
                fieldValues = JSON.parse(asset.field_values);
            } catch (e) {
                console.error('Error parsing field_values:', e);
                fieldValues = {};
            }
        }

        let assignedTo = null;
        if (asset.assigned_to_emp_id) {
            const [employee] = await db.query(
                `SELECT 
                    id, 
                    CONCAT(first_name, ' ', last_name) as name,
                    email
                FROM employee_info 
                WHERE id = ?`,
                [asset.assigned_to_emp_id]
            );

            if (employee.length > 0) {
                assignedTo = {
                    ...employee[0]
                };
            }
        }
        else if (asset.assigned_to_admin_id) {
            const [admin] = await db.query(
                `SELECT 
                    id, 
                    CONCAT(first_name, ' ', last_name) as name,
                    email
                FROM super_admin 
                WHERE id = ?`,
                [asset.assigned_to_admin_id]
            );

            if (admin.length > 0) {
                assignedTo = {
                    ...admin[0]
                };
            }
        }



        res.json({
            success: true,
            data: {
                id: asset.id,
                asset_tag: asset.asset_tag,
                category_id: asset.category_id,
                category_name: asset.category_name,
                name: asset.name,
                status: asset.status,
                field_values: fieldValues,
                assigned_to: assignedTo,
                assigned_at: asset.assigned_at,
                created_at: asset.created_at,
                updated_at: asset.updated_at,
                created_by: asset.created_by
            },
        });

    } catch (error) {
        console.error('Error in getAssetById:', error);
        res.status(500).json({
            success: false,
            message: 'Internal server error',
            error: error.message
        });
    }
};

const updateAsset = async (req, res) => {
    try {
        const db = req.db;
        const { id } = req.params;
        const {
            asset_tag,
            asset_type,
            assign_to,
            field_values,
        } = req.body;

        const [existing] = await db.query(
            'SELECT * FROM assets WHERE id = ?',
            [id]
        );

        if (existing.length === 0) {
            return res.status(404).json({
                success: false,
                message: 'Asset not found'
            });
        }

        const asset = existing[0];

        // Check duplicate asset tag
        if (asset_tag && asset_tag !== asset.asset_tag) {
            const [duplicate] = await db.query(
                'SELECT id FROM assets WHERE asset_tag = ? AND id != ?',
                [asset_tag, id]
            );

            if (duplicate.length > 0) {
                return res.status(400).json({
                    success: false,
                    message: 'Asset tag already exists'
                });
            }
        }

        // Get category id if type provided
        let category_id = asset.category_id;
        if (asset_type) {
            const [category] = await db.query(
                'SELECT id FROM asset_categories WHERE name = ?',
                [asset_type]
            );
            if (category.length === 0) {
                return res.status(400).json({
                    success: false,
                    message: 'Category not found'
                });
            }
            category_id = category[0].id;
        }

        // Handle assignment - FIXED LOGIC
        let assigned_to_emp_id = asset.assigned_to_emp_id;
        let assigned_to_admin_id = asset.assigned_to_admin_id;

        if (assign_to !== undefined) {
            if (!assign_to) {
                assigned_to_emp_id = null;
                assigned_to_admin_id = null;
            } else {
                // First check employee
                const [emp] = await db.query(
                    'SELECT id FROM employee_info WHERE id = ?',
                    [assign_to]
                );
                
                if (emp.length > 0) {
                    assigned_to_emp_id = assign_to;
                    assigned_to_admin_id = null;
                } else {
                    const [admin] = await db.query(
                        'SELECT id FROM super_admin WHERE id = ?',
                        [assign_to]
                    );
                    
                    if (admin.length > 0) {
                        assigned_to_emp_id = null;
                        assigned_to_admin_id = assign_to;
                    } else {
                        return res.status(400).json({
                            success: false,
                            message: 'User not found'
                        });
                    }
                }
            }
        }

        // Merge field values
        let mergedFields = {};
        if (asset.field_values) {
            try {
                mergedFields = JSON.parse(asset.field_values);
            } catch (e) {
                mergedFields = {};
            }
        }

        if (field_values) {
            mergedFields = { ...mergedFields, ...field_values };
        }

        // FIXED: Removed extra comma after assigned_to_admin_id
        await db.query(
            `UPDATE assets 
             SET asset_tag = COALESCE(?, asset_tag),
                 category_id = COALESCE(?, category_id),
                 field_values = ?,
                 assigned_to_emp_id = ?,
                 assigned_to_admin_id = ?
             WHERE id = ?`,
            [
                asset_tag,
                category_id,
                JSON.stringify(mergedFields),
                assigned_to_emp_id,
                assigned_to_admin_id,
                id
            ]
        );

        const [updated] = await db.query(
            `SELECT a.*, ac.name as category_name 
             FROM assets a
             JOIN asset_categories ac ON a.category_id = ac.id
             WHERE a.id = ?`,
            [id]
        );

        if (updated[0].field_values) {
            updated[0].field_values = JSON.parse(updated[0].field_values);
        }

        res.json({
            success: true,
            message: 'Asset updated successfully',
            data: updated[0]
        });

    } catch (error) {
        console.error('Error:', error);
        res.status(500).json({
            success: false,
            message: error.message
        });
    }
};


module.exports = {
    generateUniqueBarcode,
    createAssets,
    getAllAssets,
    getAssetById,
    updateAsset
}