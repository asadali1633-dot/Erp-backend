// modules.config.js
module.exports = {
  overview: {
    fields: [],
    actions: ["company_update"]
  },

  // Brand: {
  //   fields: [],
  //   actions: ["view","create"]
  // },

  // roles: {
  //   fields: [],
  //   actions: ["view","create"]
  // },
  // department: {
  //   fields: [],
  //   actions: ["view","create"]
  // },
  // designation: {
  //   fields: [],
  //   actions: ["view","create"]
  // },

  // software: {
  //   fields: ["name", "license_key", "expiry_date", "price"],
  //   actions: ["view", "create", "update", "delete"]
  // },

  // hardware: {
  //   fields: [],
  //   actions: ["view", "create", "update", "delete"]
  // },

  // tickets: {
  //   fields: [],
  //   actions: ["view", "create", "update", "delete","assign","close"]
  // },

  // vendor: {
  //   fields: [],
  //   actions: ["view", "create", "update", "delete","approved"]
  // },

  // purchase_order: {
  //   fields: [],
  //   actions: ["view", "create", "update", "delete"]
  // },

  // people: {
  //   fields: [],
  //   actions: ["view", "create", "update", "delete"]
  // },

 
};
