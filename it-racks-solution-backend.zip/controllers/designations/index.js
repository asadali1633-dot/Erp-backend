const dbHelper = require("../../db/dbhelper");



const GetAllDesignations = async (req, res) => {
    try {
        const db = req.db; 
        const admin_id = req.user.admin_id ? req.user.admin_id : req.user.id;

        const [rows] = await db.execute(
            `SELECT id, designation_name FROM designations WHERE admin_id = ? ORDER BY id ASC`,
            [admin_id]
        );

        if (rows.length === 0) {
            return res.status(200).json({
                failed: true,
                message: "No designation found",
                designations: [],
            });
        }

        return res.status(200).json({
            success: true,
            message: "designation fetched successfully",
            designations: rows,
        });
    } catch (error) {
        console.error("GetDesignations Error:", error);
        return res.status(500).json({
            failed: true,
            message: "Something went wrong",
            error: error.message,
        });
    }
};

const CreateDesignation = async (req, res) => {
    try {
        const db = req.db; 
        const admin_id = req.user.admin_id ? req.user.admin_id : req.user.id;
        const { designation } = req.body;

        const [existingDepartment] = await db.execute(
            `SELECT id FROM designations WHERE designation_name = ? AND admin_id = ?`,
            [designation, admin_id]
        );

        if (existingDepartment.length > 0) {
            return res.status(400).json({
                failed: true,
                message: "This designation already exists under your account",
            });
        }

        const [result] = await db.execute(
            `INSERT INTO designations (designation_name, admin_id) VALUES (?, ?)`,
            [designation, admin_id]
        );

        return res.status(201).json({
            success: true,
            message: "designation created successfully",
            designationid: result.insertId,
        });
    } catch (error) {
        return res.status(500).json({
            failed: true,
            message: "Something went wrong",
            error: error.message,
        });
    }
};

module.exports = {
    CreateDesignation,
    GetAllDesignations,
}
