


const saveEducation = async (req, res) => {
    try {
        const db = req.db;
        const admin_id = req.user.admin_id || req.user.id;

        const {
            id,
            employeeId,
            level,
            institute_name,
            board,
            completed_year,
            city,
        } = req.body;

        let employee_id = null;

        if (req.user.admin_id && ["EMPLOYEE", "ADMIN", "MANAGER"].includes(req.user.user_type)) {
            employee_id = req.user.id;
        }
        else if (req.user.admin_id && req.user.user_type === "HR") {
            employee_id = employeeId || req.user.id;
        }
        else {
            employee_id = employeeId || null;
        }

        const certificate = req.file
            ? `/uploads/edu_certificates/${req.file.filename}`
            : null;

        if (!id) {
            const [duplicate] = await db.execute(
                `SELECT id FROM education
                    WHERE admin_id = ? AND employee_id = ? AND level = ?`,
                [admin_id, employee_id, level]
            );

            if (duplicate.length > 0) {
                return res.status(409).json({
                    success: false,
                    message: "Duplicate entry: Education level already exists",
                });
            }

            await db.execute(
                `INSERT INTO education
                (admin_id, employee_id, level, institute_name, board, completed_year, city, certificate_file)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)`,
                [admin_id,employee_id,level,institute_name,board,completed_year,city,certificate]
            );

            return res.status(200).json({
                success: true,
                message: "Education added successfully",
            });
        }

        const [conflict] = await db.execute(
            `SELECT id FROM education
                WHERE admin_id = ? AND employee_id = ? AND level = ? AND id != ?`,
            [admin_id, employee_id, level, id]
        );

        if (conflict.length > 0) {
            return res.status(409).json({
                success: false,
                message: "Education level already used by another record",
            });
        }

        await db.execute(
            `UPDATE education SET
                level = ?,
                institute_name = ?,
                board = ?,
                completed_year = ?,
                city = ?,
                certificate_file = COALESCE(?, certificate_file)
                WHERE id = ?`,
            [level,institute_name,board,completed_year,city,certificate,id]
        );

        return res.status(200).json({
            success: true,
            message: "Education updated successfully",
        });

    } catch (error) {
        console.error("Education Error:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                success: false,
                message: "Duplicate education not allowed",
            });
        }

        return res.status(500).json({
            success: false,
            message: "Something went wrong",
        });
    }
};


const getEducationById = async (req, res) => {
    try {
        const db = req.db;
        const admin_id = req.user.admin_id || req.user.id;
        const targetEmployeeId = req.params.id;
        let employee_id = targetEmployeeId || req.user.id;

        const [rows] = await db.execute(
            `SELECT id, level, institute_name, board, completed_year, city, certificate_file 
                FROM education 
            WHERE admin_id = ? AND employee_id = ?`,
            [admin_id, employee_id]
        );

        return res.status(200).json({
            success: true,
            data: rows,
        });

    } catch (error) {
        console.error("Get Education Error:", error);
        return res.status(500).json({
            success: false,
            message: "Something went wrong",
        });
    }
};

const getEducationByEduId = async (req, res) => {
    try {
        const db = req.db;
        const admin_id = req.user.admin_id || req.user.id;
        const educationId = req.params.id;

        // Fetch single education by id AND admin_id
        const [rows] = await db.execute(
            `SELECT id, level, institute_name, board, completed_year, city, certificate_file, employee_id
                FROM education
            WHERE id = ? AND admin_id = ?`,
            [educationId, admin_id]
        );

        if (!rows.length) {
            return res.status(404).json({
                success: false,
                message: "Education not found",
            });
        }

        return res.status(200).json({
            success: true,
            data: rows[0],
        });

    } catch (error) {
        console.error("Get Education By ID Error:", error);
        return res.status(500).json({
            success: false,
            message: "Something went wrong",
        });
    }
};


module.exports = {
    saveEducation,
    getEducationById,
    getEducationByEduId
};