


const saveExperience = async (req, res) => {
    try {
        const db = req.db;
        const admin_id = req.user.admin_id || req.user.id;

        const {
            id,
            employeeId,
            company_name,
            industry,
            job_title,
            employment_type,
            start_date,
            end_date,
            currently_working,
            responsibilities,
            reason_for_leaving,
        } = req.body;

        let employee_id = null;

        if (req.user.admin_id && ["EMPLOYEE", "ADMIN", "MANAGER"].includes(req.user.user_type)) {
            employee_id = req.user.id;
        }
        else if (req.user.admin_id && req.user.user_type === "HR") {
            employee_id = employeeId || req.user.id;
        }
        else {
            employee_id = employeeId || null;
        }

        const document = req.file
            ? `/uploads/experience_docs/${req.file.filename}`
            : null;

        if (!id) {
            // const [duplicate] = await db.execute(
            //     `SELECT id FROM experience
            //         WHERE admin_id = ? AND employee_id = ? AND job_title = ?`,
            //     [admin_id, employee_id, job_title]
            // );

            // if (duplicate.length > 0) {
            //     return res.status(409).json({
            //         success: false,
            //         message: "Duplicate entry: Experience already exists",
            //     });
            // }

            await db.execute(
                `INSERT INTO experience
                (admin_id, employee_id, company_name, industry, job_title,
                employment_type, start_date, end_date, currently_working,
                responsibilities, reason_for_leaving, document_file)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
                [
                    admin_id,
                    employee_id,
                    company_name,
                    industry,
                    job_title,
                    employment_type,
                    start_date,
                    end_date,
                    currently_working,
                    responsibilities,
                    reason_for_leaving,
                    document,
                ]
            );

            return res.status(200).json({
                success: true,
                message: "Experience added successfully",
            });
        }

        // const [conflict] = await db.execute(
        //     `SELECT id FROM experience
        //         WHERE admin_id = ? AND employee_id = ? AND job_title = ? AND id != ?`,
        //     [admin_id, employee_id, job_title, id]
        // );

        // if (conflict.length > 0) {
        //     return res.status(409).json({
        //         success: false,
        //         message: "This experience already exists for another record",
        //     });
        // }

        await db.execute(
            `UPDATE experience SET
                company_name = ?,
                industry = ?,
                job_title = ?,
                employment_type = ?,
                start_date = ?,
                end_date = ?,
                currently_working = ?,
                responsibilities = ?,
                reason_for_leaving = ?,
                document_file = COALESCE(?, document_file)
                WHERE id = ?`,
            [
                company_name,
                industry,
                job_title,
                employment_type,
                start_date,
                end_date,
                currently_working,
                responsibilities,
                reason_for_leaving,
                document,
                id,
            ]
        );

        return res.status(200).json({
            success: true,
            message: "Experience updated successfully",
        });

    } catch (error) {
        console.error("Experience Error:", error);

        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                success: false,
                message: "Duplicate experience not allowed",
            });
        }

        return res.status(500).json({
            success: false,
            message: "Something went wrong",
        });
    }
};

const getExperienceByEmployee = async (req, res) => {
    try {
        const db = req.db;
        const admin_id = req.user.admin_id || req.user.id;
        const targetEmployeeId = req.params.id;
        const employee_id = targetEmployeeId || req.user.id;

        const [rows] = await db.execute(
            `SELECT * FROM experience
                WHERE admin_id = ? AND employee_id = ?
            ORDER BY start_date DESC`,
            [admin_id, employee_id]
        );

        return res.status(200).json({
            success: true,
            data: rows,
        });

    } catch (error) {
        console.error("Get Experience Error:", error);
        return res.status(500).json({
            success: false,
            message: "Something went wrong",
        });
    }
};

const getExperienceById = async (req, res) => {
    try {
        const db = req.db;
        const admin_id = req.user.admin_id || req.user.id;
        const experienceId = req.params.id;

        const [rows] = await db.execute(
            `SELECT 
                id,
                admin_id,
                employee_id,
                company_name,
                industry,
                job_title,
                employment_type,
                start_date,
                end_date,
                currently_working,
                CASE 
                    WHEN currently_working = 1 THEN 'Yes'
                    ELSE 'No'
                END AS currently_working,
                responsibilities,
                reason_for_leaving,
                document_file,
                created_at,
                updated_at
                FROM experience
                WHERE id = ? AND admin_id = ?`,
            [experienceId, admin_id]
        );

        if (!rows.length) {
            return res.status(404).json({
                success: false,
                message: "Experience not found",
            });
        }

        return res.status(200).json({
            success: true,
            data: rows[0],
        });

    } catch (error) {
        console.error("Get Experience By ID Error:", error);
        return res.status(500).json({
            success: false,
            message: "Something went wrong",
        });
    }
};




module.exports = {
    saveExperience,
    getExperienceByEmployee,
    getExperienceById
};