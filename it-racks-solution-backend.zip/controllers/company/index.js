
const dbHelper = require("../../db/dbhelper");


const registerCompany = async (req, res) => {
  try {
    const db = req.db; 
    const userId = req.user.id;
    const { company, domain, ntn_vat, phone, address, state_province, country, city } = req.body;

    let imagePath = null;
    if (req.file) {
      imagePath = "/uploads/companies_images/" + req.file.filename;
    }

    // Check if user already has a company
    const [existing] = await db.execute(
      `SELECT id FROM companies WHERE admin_id  = ?`,
      [userId]
    );

    if (existing.length > 0) {
      return res.status(400).json({
        failed: false,
        message: "You already registered a company.",
      });
    }

    const generateBusinessId = () => {
      const firstPart = Math.floor(10000000 + Math.random() * 90000000); // 8 digits
      const secondPart = Math.floor(10 + Math.random() * 90); // 2 digits
      return `${firstPart}-${secondPart}`;
    };

    const businessId = generateBusinessId();

    const sql = `
      INSERT INTO companies 
      (admin_id, company, domain, ntn_vat, phone, address, state_province, country, city, image, business_id) 
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `;

    const values = [
      userId,
      company,
      domain,
      ntn_vat,
      phone,
      address,
      state_province,
      country,
      city,
      imagePath,
      businessId,
    ];

    const [result] = await db.execute(sql, values);

    res.status(201).json({
      success: true,
      message: "Company registered successfully",
      companyId: result.insertId,
      business_id: businessId,
      image: imagePath,
    });
  } catch (err) {
    console.error("Create Company Error:", err);
    res.status(500).json({ failed: false, message: "Something went wrong" });
  }
};

const GetUser = async (req, res) => {
  try {
    const db = req.db; 
    let userData = null;
    let permissions = [];
    let adminId = null;

    if (req.user.admin_id) {
      const employeeId = req.user.id;
      adminId = req.user.admin_id;

      const [rows] = await db.execute(
        `SELECT 
          ei.id,
          CONCAT(ei.first_name, ' ', ei.last_name) AS name,
          ei.email,
          ei.role,
          ei.user_type,
          ei.mobile_number AS phone,
          ei.designation,
          ei.department,
          ei.created_at,
          ei.admin_id,
          ei.profile_image,
          ei.full_address,
          ei.date_of_birth
        FROM employee_info ei
        WHERE ei.id = ? AND ei.admin_id = ?`,
        [employeeId,adminId]
      );

      if (!rows.length) {
        return res.status(404).json({ success: false, message: "Employee not found" });
      }

      userData = {
        ...rows[0],
        user_type: rows[0]?.user_type,
      };

      const [permissionRows] = await db.query(
        `SELECT DISTINCT p.slug
         FROM employee_permissions ep
         INNER JOIN permissions p ON p.id = ep.permission_id
         WHERE ep.employee_id = ?
           AND ep.admin_id = ?
           AND ep.assigned = 1`,
        [employeeId, adminId]
      );

      permissions = permissionRows.map(p => p.slug);
    }

    else {
      adminId = req.user.id;
      const [rows] = await db.execute(
        `SELECT 
          a.id,
          CONCAT(a.first_name, ' ', a.last_name) AS name,
          a.email,
          a.user_type,
          a.profile_image,
          a.full_address,
          a.role,
          a.designation,
          a.department,
          a.date_of_birth,
          a.created_at
        FROM admin a
        WHERE a.id = ?`,
        [adminId]
      );

      if (!rows.length) {
        return res.status(404).json({ success: false, message: "Admin not found" });
      }

      userData = {
        ...rows[0],
        phone: null,
        designation: null,
        department: null,
        admin_id: adminId
      };
      const [permissionRows] = await db.query(`SELECT slug FROM permissions`);
      permissions = permissionRows.map(p => p.slug);
    }

    const [companyRows] = await db.execute(
      `SELECT phone, business_id, domain
       FROM companies
       WHERE admin_id = ?
       LIMIT 1`,
      [adminId]
    );

    const company = companyRows[0] || {};
    return res.status(200).json({
      success: true,
      message: "User fetched successfully",
      data: {
        ...userData,
        permissions,
        company_phone: company.phone || null,
        business_id: company.business_id || null,
        domain: company.domain || null
      }
    });

  } catch (err) {
    console.error("GetUser Error:", err);
    return res.status(500).json({
      failed: false,
      message: "Something went wrong",
      error: err.message
    });
  }
};

const GetCompanyByAdmin = async (req, res) => {
  try {
    const db = req.db; 
    const userId = req.user.admin_id ? req.user.admin_id : req.user.id;
    const [companyRows] = await db.execute(
      `SELECT 
        id, 
        domain, 
        company, 
        phone, 
        address, 
        zipcode, 
        business_id, 
        whatsapp_no, 
        website_url, 
        image, 
        brief_note, 
        created_at, 
        modified_date
       FROM companies
       WHERE admin_id = ?
       LIMIT 1`,
      [userId]
    );

    return res.status(200).json({
      success: true,
      company: companyRows.length ? companyRows[0] : null
    });

  } catch (err) {
    console.error("GetCompany Error:", err);
    return res.status(500).json({
      failed: false,
      message: "Something went wrong",
      error: err.message
    });
  }
};

const UpdateCompany = async (req, res) => {
  try {
    const db = req.db; 
    const userId = req.user.admin_id ? req.user.admin_id : req.user.id;
    const {
      phone = null,
      whatsapp_no = null,
      website_url = null,
      domain = null,
      address = null,
      zipcode = null,
      brief_note = null,
    } = req.body;

    const [existing] = await db.execute(
      "SELECT id FROM companies WHERE admin_id = ? LIMIT 1",
      [userId]
    );

    if (existing.length === 0) {
      return res.status(404).json({ failed: true, message: "Company not found" });
    }

    await db.execute(
      `
      UPDATE companies 
      SET phone = ?, whatsapp_no = ?, website_url = ?, domain = ?, 
      address = ?, zipcode = ?, brief_note = ?, 
      modified_date = NOW()
      WHERE admin_id = ?
      `,
      [phone, whatsapp_no, website_url, domain, address, zipcode, brief_note, userId]
    );

    res.status(200).json({
      success: true,
      message: "Company updated successfully",
    });
  } catch (err) {
    console.error("UpdateCompany Error:", err);
    res.status(500).json({ failed: true, message: "Something went wrong" });
  }
};




module.exports = {
  registerCompany,
  GetUser,
  UpdateCompany,
  GetCompanyByAdmin
}

