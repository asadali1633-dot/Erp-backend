const dbHelper = require("../../db/dbhelper");



const GetAllBrandsManufacturer = async (req, res) => {
    try {
        const db = req.db; 
        const admin_id = req.user.admin_id ? req.user.admin_id : req.user.id;
        const [rows] = await db.execute(
            `SELECT id, brand_manufacturer FROM brand_manufacturer WHERE admin_id = ? ORDER BY id ASC`,
            [admin_id]
        );

        return res.status(200).json({
            success: true,
            brands: rows,
        });
    } catch (error) {
        console.error("GetAllBrands Error:", error);
        return res.status(500).json({
            failed: true,
            message: "Something went wrong",
            error: error.message,
        });
    }
};

const CreateBrand = async (req, res) => {
    try {
        const db = req.db; 
        const admin_id = req.user.admin_id ? req.user.admin_id : req.user.id;
        const { brand, brand_manufacturer } = req.body;
        const brandName = brand_manufacturer || brand;

        const [existingBrand] = await db.execute(
            `SELECT id FROM brand_manufacturer WHERE brand_manufacturer = ? AND admin_id = ?`,
            [brandName, admin_id]
        );

        if (existingBrand.length > 0) {
            return res.status(400).json({
                failed: true,
                message: "This brand already exists under your account",
            });
        }

        const [result] = await db.execute(
            `INSERT INTO brand_manufacturer (admin_id, brand_manufacturer) VALUES (?, ?)`,
            [admin_id, brandName]
        );

        return res.status(201).json({
            success: true,
            message: "Brand created successfully",
            brandId: result.insertId,
        });
    } catch (error) {
        console.error("CreateBrand Error:", error);
        return res.status(500).json({
            failed: true,
            message: "Something went wrong",
            error: error.message,
        });
    }
};


module.exports = {
    GetAllBrandsManufacturer,
    CreateBrand,
}