
require("dotenv").config();
const bcrypt = require("bcryptjs");
const nodemailer = require("nodemailer");
const dbHelper = require("../../db/dbhelper");



const GenratedEmpId = async (req, res) => {
  try {
    const db = req.db;
    const admin_id = req.user.admin_id ? req.user.admin_id : req.user.id;

    const [empRows] = await db.execute(
      `SELECT emp_id 
                FROM employee_info 
                WHERE admin_id = ?
                ORDER BY emp_id DESC 
                LIMIT 1`,
      [admin_id]
    );

    let nextEmployeeId = "0004";

    if (empRows.length > 0) {
      const lastId = parseInt(empRows[0].emp_id, 10);
      nextEmployeeId = (lastId + 1).toString().padStart(4, "0");
    }



    return res.status(200).json({
      success: true,
      message: "Next-id Created successfully",
      next_employee_id: nextEmployeeId,
    });

  } catch (error) {
    console.log("Emp Genrated Id Error:", error);
    return res.status(500).json({
      failed: false,
      message: "Server error",
      error: error.message,
    });
  }
};

const CreatePeople = async (req, res) => {
  try {
    const db = req.db;
    const admin_id = req.user.admin_id ? req.user.admin_id : req.user.id;
    const {
      emp_id,
      first_name,
      last_name,
      email,
      department,
      role,
      designation,
      mobile_number,
      whatsapp_number,
      emergency_number,
      phone_extension,
      full_address,
      province,
      country,
      city,
      postal_code,
      facebook_link,
      linkedin_link,
      x_link,
      blood_group,
      gender,
      joining_date,
      date_of_birth,
      identity_type,
      status,
      identity_number,
      user_type
    } = req.body;

    const [existing] = await db.execute(
      `SELECT email FROM employee_info WHERE email = ?
       UNION
       SELECT email FROM admin WHERE email = ?`,
      [email, email]
    );

    if (existing.length > 0) {
      return res.status(409).json({
        success: false,
        message: "Email already exists in the system. Please use a different email.",
      });
    }

    const plainPassword = "123456789";
    const hashedPassword = await bcrypt.hash(plainPassword, 10);

    const sql = `
      INSERT INTO employee_info (
        admin_id, emp_id, first_name, last_name, email, password,
        department, role, designation,
        mobile_number, whatsapp_number, emergency_number, phone_extension,
        full_address, province, country, city, postal_code,
        facebook_link, linkedin_link, x_link,
        blood_group, gender, joining_date, date_of_birth,
        identity_type, identity_number, status, user_type
      ) VALUES (
        ?, ?, ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?, ?, ?, ?,
        ?, ?, ?,
        ?, ?, ?, ?,
        ?, ?, ?,?
      )
    `;

    const [result] = await db.execute(sql, [
      admin_id, emp_id, first_name, last_name, email, hashedPassword,
      department, role, designation,
      mobile_number || null, whatsapp_number || null, emergency_number || null,
      phone_extension || null, full_address || null, province || null, country || null,
      city || null, postal_code || null, facebook_link || null, linkedin_link || null,
      x_link || null, blood_group || null, gender || null, joining_date || null,
      date_of_birth || null, identity_type || null, identity_number || null,
      status || null, user_type || null
    ]);

    const transporter = nodemailer.createTransport({
      service: "gmail",
      auth: {
        user: process.env.EMAIL_CONFIG,
        pass: process.env.EMAIL_PASS,
      },
    });

    const mailOptions = {
      from: `"Support Team" <${process.env.EMAIL_CONFIG}>`,
      to: email,
      subject: "Your Account Credentials",
      html: `
        <h3>Hello ${first_name},</h3>
        <p>Your account has been created successfully.</p>
        <p><b>Email:</b> ${email}</p>
        <p><b>Password:</b> ${plainPassword}</p>
        <p>Please change your password after your first login for security reasons. <a href="https://software.itrackspace.com/EmailScreenPassword">https://software.itrackspace.com/EmailScreenPassword</a></p>
        <br/>
        <p>Regards,<br/>Admin Team</p>
      `,
    };
    await transporter.sendMail(mailOptions);

    return res.status(201).json({
      success: true,
      message: "User created successfully and credentials emailed.",
      userId: result.insertId,
    });

  } catch (error) {
    console.error("CreateUser Error:", error);
    return res.status(500).json({
      failed: false,
      message: "Server error",
      error: error.message,
    });
  }
};

const UpdatePeople = async (req, res) => {
  try {
    const db = req.db;
    const admin_id = req.user.admin_id ? req.user.admin_id : req.user.id;
    const { id } = req.params;

    const [empCheck] = await db.execute(
      `SELECT id FROM employee_info WHERE id = ? AND admin_id = ?`,
      [id, admin_id]
    );

    if (!empCheck.length) {
      return res.status(404).json({
        success: false,
        message: "Employee not found",
      });
    }

    if (req.body.email) {
      const [existing] = await db.execute(
        `SELECT email FROM employee_info WHERE email = ? AND id != ?
          UNION
        SELECT email FROM admin WHERE email = ?
        `,
        [req.body.email, id, req.body.email]
      );
      if (existing.length > 0) {
        return res.status(409).json({
          success: false,
          message: "Email already exists in the system.",
        });
      }
    }

    const allowedFields = [
      "emp_id",
      "first_name",
      "last_name",
      "email",
      "department",
      "role",
      "designation",
      "mobile_number",
      "whatsapp_number",
      "emergency_number",
      "phone_extension",
      "full_address",
      "province",
      "country",
      "city",
      "postal_code",
      "facebook_link",
      "linkedin_link",
      "x_link",
      "blood_group",
      "gender",
      "joining_date",
      "date_of_birth",
      "identity_type",
      "identity_number",
      "status",
      "user_type",
    ];

    const updateFields = [];
    const values = [];

    allowedFields.forEach((field) => {
      if (req.body[field] !== undefined) {
        updateFields.push(`${field} = ?`);
        values.push(req.body[field]);
      }
    });

    if (!updateFields.length) {
      return res.status(400).json({
        failed: false,
        message: "No fields provided to update",
      });
    }

    const sql = `
      UPDATE employee_info
      SET ${updateFields.join(", ")}
      WHERE id = ? AND admin_id = ?
    `;

    values.push(id, admin_id);
    await db.execute(sql, values);

    return res.status(200).json({
      success: true,
      message: "Employee updated successfully",
    });

  } catch (error) {
    console.error("UpdatePeople Error:", error);
    return res.status(500).json({
      failed: false,
      message: "Server error",
      error: error.message,
    });
  }
};

const DeleteEmployees = async (req, res) => {
  try {
    const db = req.db;
    let { ids } = req.body;
    const admin_id = req.user.admin_id ? req.user.admin_id : req.user.id;

    if (!Array.isArray(ids)) {
      ids = [ids];
    }

    if (!ids.length) {
      return res.status(400).json({
        success: false,
        message: "No employee IDs provided",
      });
    }

    const placeholders = ids.map(() => "?").join(",");

    const sql = `
      DELETE FROM employee_info
      WHERE id IN (${placeholders})
      AND admin_id = ?
    `;

    const [result] = await db.execute(sql, [...ids, admin_id]);

    return res.status(200).json({
      success: true,
      message: "Employee(s) deleted successfully",
      deletedCount: result.affectedRows,
    });

  } catch (error) {
    console.error("DeleteEmployees Error:", error);
    return res.status(500).json({
      success: false,
      message: "Server error",
      error,
    });
  }
};

const GetEmpByIdSearchWithPagination = async (req, res) => {
  try {
    const db = req.db;
    const admin_id = req.user.admin_id ? req.user.admin_id : req.user.id;
    const { page = 1, limit = 10, search = "" } = req.query;
    const offset = (page - 1) * limit;

    let whereClause = "WHERE e.admin_id = ?";
    let values = [admin_id];

    if (search) {
      whereClause += `
        AND (
          e.emp_id = ?
          OR e.first_name LIKE ?
          OR e.last_name LIKE ?
          OR e.email LIKE ?
        )
      `;
      values.push(search, `%${search}%`, `%${search}%`, `%${search}%`);
    }

    const [countResult] = await db.execute(
      `SELECT COUNT(*) as total
       FROM employee_info e
       ${whereClause}`,
      values
    );

    const total = countResult[0].total;

    // 📄 Data
    const [rows] = await db.execute(
      `SELECT 
          e.id,
          e.emp_id,
          e.first_name,
          e.last_name,
          e.email,

          e.role AS role_id,
          r.role_name AS role_name,

          e.designation AS designation_id,
          dg.designation_name AS designation_name,

          e.department AS department_id,
          d.department AS department_name,

          e.mobile_number,
          e.whatsapp_number,
          e.status,
          e.created_at

       FROM employee_info e

       LEFT JOIN departments d 
         ON e.department = d.id

       LEFT JOIN roles r 
         ON e.role = r.id

       LEFT JOIN designations dg 
         ON e.designation = dg.id

       ${whereClause}
       ORDER BY e.created_at DESC
       LIMIT ? OFFSET ?`,
      [...values, Number(limit), Number(offset)]
    );

    return res.status(200).json({
      success: true,
      page: Number(page),
      limit: Number(limit),
      total,
      totalPages: Math.ceil(total / limit),
      employees: rows,
    });

  } catch (error) {
    console.error("GetEmployees Error:", error);
    return res.status(500).json({
      success: false,
      message: "Server error",
      error: error.message,
    });
  }
};


const GetSuperAdminById = async (req, res) => {
  try {
    const db = req.db;
    const admin_id = req.user.admin_id || req.user.id;
    const user_type = req.user.user_type
    let employee_id = null;
    
    if (req.user.id && user_type === "Super_admin"){
      employee_id = admin_id;
    }

    const [admins] = await db.execute(
      `SELECT
        a.id,
        a.first_name,
        a.last_name,
        a.email,
        a.mobile_number,
        a.whatsapp_number,
        a.emergency_number,
        a.phone_extension,

        a.joining_date,
        a.identity_type,
        a.identity_number,

        a.role,
        r.role_name,

        a.designation,
        dg.designation_name,

        a.department,
        d.department AS department_name,

        a.full_address,
        a.province,
        a.city,
        a.country,
        a.postal_code,

        a.facebook_link,
        a.linkedin_link,
        a.x_link,

        a.gender,
        a.date_of_birth,
        a.blood_group,

        a.profile_image,
        a.status,
        a.user_type,
        a.created_at,
        'super_admin' AS source
      FROM admin a
      LEFT JOIN roles r ON a.role = r.id
      LEFT JOIN designations dg ON a.designation = dg.id
      LEFT JOIN departments d ON a.department = d.id
      WHERE a.id = ?
      LIMIT 1`,
      [employee_id]
    );

    if (!admins.length) {
      return res.status(404).json({
        success: false,
        message: "Record not found",
      });
    }

    return res.status(200).json({
      success: true,
      data: admins[0],
    });

  } catch (error) {
    console.error("GetEmployeeById Error:", error);
    return res.status(500).json({
      success: false,
      message: "Something went wrong",
    });
  }
};
// const GetEmployeeById = async (req, res) => {
//   try {
//     const db = req.db;
//     const admin_id = req.user.admin_id || req.user.id;
//     const user_type = req.user.user_type
//     const targetId = req.params.id;
//     let employee_id = null;
//     let superAdmin = null

//     console.log("user_type",user_type)

//     if (req.user.admin_id && ["EMPLOYEE", "MANAGER", "ADMIN"].includes(user_type)) {
//       employee_id = req.user.id;
//     }
//     else if (req.user.admin_id && user_type === "HR") {
//       employee_id = targetId || req.user.id;
//       console.log("hr",user_type)
//     }
//     else if (req.user.id && user_type === "Super_admin"){
//       employee_id = targetId;
//       console.log("super admin",user_type)

//     }
    
//     const [employees] = await db.execute(
//       `SELECT 
//         e.id,
//         e.emp_id,
//         e.first_name,
//         e.last_name,
//         e.email,

//         e.role,
//         r.role_name,

//         e.designation,
//         dg.designation_name,

//         e.department,
//         d.department AS department_name,

//         e.mobile_number,
//         e.whatsapp_number,
//         e.emergency_number,
//         e.phone_extension,

//         e.full_address,
//         e.province,
//         e.city,
//         e.country,
//         e.postal_code,

//         e.facebook_link,
//         e.linkedin_link,
//         e.x_link,

//         e.blood_group,
//         e.gender,
//         e.joining_date,
//         e.date_of_birth,

//         e.identity_type,
//         e.identity_number,
//         e.profile_image,

//         e.status,
//         e.user_type,
//         e.created_at,
//         'employee' AS source
//       FROM employee_info e
//       LEFT JOIN departments d ON e.department = d.id
//       LEFT JOIN roles r ON e.role = r.id
//       LEFT JOIN designations dg ON e.designation = dg.id
//       WHERE e.admin_id = ? AND e.id = ?
//       LIMIT 1`,
//       [admin_id, employee_id]
//     );

//     if (employees.length) {
//       return res.status(200).json({
//         success: true,
//         data: employees[0],
//       });
//     }

//     const [admins] = await db.execute(
//       `SELECT
//         a.id,
//         a.first_name,
//         a.last_name,
//         a.email,
//         a.mobile_number,
//         a.whatsapp_number,
//         a.emergency_number,
//         a.phone_extension,

//         a.joining_date,
//         a.identity_type,
//         a.identity_number,

//         a.role,
//         r.role_name,

//         a.designation,
//         dg.designation_name,

//         a.department,
//         d.department AS department_name,

//         a.full_address,
//         a.province,
//         a.city,
//         a.country,
//         a.postal_code,

//         a.facebook_link,
//         a.linkedin_link,
//         a.x_link,

//         a.gender,
//         a.date_of_birth,
//         a.blood_group,

//         a.profile_image,
//         a.status,
//         a.user_type,
//         a.created_at,
//         'super_admin' AS source
//       FROM admin a
//       LEFT JOIN roles r ON a.role = r.id
//       LEFT JOIN designations dg ON a.designation = dg.id
//       LEFT JOIN departments d ON a.department = d.id
//       WHERE a.id = ?
//       LIMIT 1`,
//       [employee_id]
//     );

//     if (!admins.length) {
//       return res.status(404).json({
//         success: false,
//         message: "Record not found",
//       });
//     }

//     return res.status(200).json({
//       success: true,
//       data: admins[0],
//     });

//   } catch (error) {
//     console.error("GetEmployeeById Error:", error);
//     return res.status(500).json({
//       success: false,
//       message: "Something went wrong",
//     });
//   }
// };

const GetAllEmployeesBySimpleList = async (req, res) => {
  try {
    const db = req.db;
    const admin_id = req.user.admin_id ? req.user.admin_id : req.user.id;

    const [rows] = await db.execute(
      `SELECT 
          e.id,
          e.emp_id,
          CONCAT(e.first_name, ' ', e.last_name) AS name,
          e.email,
          e.status
       FROM employee_info e
       WHERE e.admin_id = ?`,
      [admin_id]
    );

    return res.status(200).json({
      success: true,
      employees: rows,
    });

  } catch (error) {
    console.error("GetAllEmployeesByAdmin Error:", error);
    return res.status(500).json({
      success: false,
      message: "Server error",
      error,
    });
  }
};

const UpdateSuperAdmin = async (req, res) => {
  try {
    const db = req.db;
    const admin_id = req.user.id;
    const [adminCheck] = await db.execute(
      `SELECT id FROM admin WHERE id = ?`,
      [admin_id]
    );

    if (!adminCheck.length) {
      return res.status(404).json({
        success: false,
        message: "Super Admin not found",
      });
    }

    // Email uniqueness check
    if (req.body.email) {
      const [existing] = await db.execute(
        `SELECT email FROM employee_info WHERE email = ?
         UNION
         SELECT email FROM admin WHERE email = ? AND id != ?`,
        [req.body.email, req.body.email, admin_id]
      );

      if (existing.length) {
        return res.status(409).json({
          success: false,
          message: "Email already exists in the system",
        });
      }
    }

    const allowedFields = [
      "emp_id",
      "first_name",
      "last_name",
      "email",
      "department",
      "role",
      "designation",
      "mobile_number",
      "whatsapp_number",
      "emergency_number",
      "phone_extension",
      "full_address",
      "province",
      "country",
      "city",
      "postal_code",
      "facebook_link",
      "linkedin_link",
      "x_link",
      "blood_group",
      "gender",
      "joining_date",
      "date_of_birth",
      "identity_type",
      "identity_number",
      "status",
      "user_type",
    ];

    const updateFields = [];
    const values = [];

    allowedFields.forEach((field) => {
      if (req.body[field] !== undefined) {
        updateFields.push(`${field} = ?`);
        values.push(req.body[field]);
      }
    });

    if (!updateFields.length) {
      return res.status(400).json({
        success: false,
        message: "No fields provided to update",
      });
    }

    const sql = `
      UPDATE admin
      SET ${updateFields.join(", ")}
      WHERE id = ?
    `;

    values.push(admin_id);

    await db.execute(sql, values);

    return res.status(200).json({
      success: true,
      message: "Super Admin updated successfully",
    });

  } catch (error) {
    console.error("UpdateSuperAdmin Error:", error);
    return res.status(500).json({
      success: false,
      message: "Server error",
      error: error.message,
    });
  }
};


const uploadUserImage = async (req, res) => {
  try {
    const db = req.db;
    const admin_id = req.user.admin_id || req.user.id;
    const { empid } = req.body;
    const userType = req.user.user_type;

    if (!req.file) {
      return res.status(400).json({
        success: false,
        message: "No image file uploaded",
      });
    }

    const imagePath = `/uploads/profile-images/${req.file.filename}`;

    let targetEmployeeId = null;
    let updateAdmin = false;

    if (["EMPLOYEE", "ADMIN", "MANAGER"].includes(userType)) {
      targetEmployeeId = req.user.id;
    }

    else if (userType === "HR") {
      targetEmployeeId = empid || req.user.id;
    }

    else if (userType === "Super_admin") {
      if (empid) {
        targetEmployeeId = empid;
      } else {
        updateAdmin = true;
      }
    }

    if (targetEmployeeId) {
      const [rows] = await db.execute(
        `SELECT id, profile_image 
         FROM employee_info 
         WHERE id = ? AND admin_id = ?`,
        [targetEmployeeId, admin_id]
      );

      if (!rows.length) {
        return res.status(404).json({
          success: false,
          message: "Employee not found",
        });
      }

      await db.execute(
        `UPDATE employee_info 
         SET profile_image = ? 
         WHERE id = ? AND admin_id = ?`,
        [imagePath, targetEmployeeId, admin_id]
      );

      return res.status(200).json({
        success: true,
        message: rows[0].profile_image
          ? "Employee profile image updated successfully"
          : "Employee profile image added successfully",
        image: imagePath,
      });
    }

    if (updateAdmin) {
      const [rows] = await db.execute(
        `SELECT id, profile_image 
         FROM admin 
         WHERE id = ?`,
        [req.user.id]
      );

      if (!rows.length) {
        return res.status(404).json({
          success: false,
          message: "Super admin not found",
        });
      }

      await db.execute(
        `UPDATE admin 
         SET profile_image = ? 
         WHERE id = ?`,
        [imagePath, req.user.id]
      );

      return res.status(200).json({
        success: true,
        message: rows[0].profile_image
          ? "Super admin profile image updated successfully"
          : "Super admin profile image added successfully",
        image: imagePath,
      });
    }

  } catch (error) {
    console.error("Upload User Image Error:", error);
    return res.status(500).json({
      success: false,
      message: "Server error",
    });
  }
};


module.exports = {
  GenratedEmpId,
  CreatePeople,
  UpdatePeople,
  DeleteEmployees,
  GetEmpByIdSearchWithPagination,
  // GetEmployeeById,
  GetSuperAdminById,
  GetAllEmployeesBySimpleList,
  UpdateSuperAdmin,
  uploadUserImage
};

