


const saveQualification = async (req, res) => {
    try {
        const db = req.db;
        const admin_id = req.user.admin_id || req.user.id;

        const {
            id,
            employeeId,
            certification_no,
            institute_name,
            completed_date,
            city,
        } = req.body;

        let employee_id = null;

        if (req.user.admin_id && ["EMPLOYEE", "ADMIN", "MANAGER"].includes(req.user.user_type)) {
            employee_id = req.user.id;
        } else if (req.user.admin_id && req.user.user_type === "HR") {
            employee_id = employeeId || req.user.id;
        } else {
            employee_id = employeeId;
        }

        const certificate = req.file
            ? `/uploads/qua_certificates/${req.file.filename}`
            : null;

        if (!id) {
            const [duplicate] = await db.execute(
                `SELECT id FROM qualification
                    WHERE admin_id = ? AND employee_id = ? AND certification_no = ?`,
                [admin_id, employee_id, certification_no]
            );

            if (duplicate.length > 0) {
                return res.status(409).json({
                    success: false,
                    message: "Duplicate entry: Certification / License (No) already exists",
                });
            }

            await db.execute(
                `INSERT INTO qualification
                (admin_id, employee_id, certification_no, institute_name, completed_date, city, certificate_file)
                VALUES (?, ?, ?, ?, ?, ?, ?)`,
                [admin_id,employee_id,certification_no,institute_name,completed_date,city,certificate]
            );

            return res.json({
                success: true,
                message: "Qualification added successfully",
            });
        }
        const [conflict] = await db.execute(
            `SELECT id FROM qualification
                WHERE admin_id = ? AND employee_id = ? AND certification_no = ? AND id != ?`,
            [admin_id, employee_id, certification_no, id]
        );

        if (conflict.length > 0) {
            return res.status(409).json({
                success: false,
                message: "Certification / License (No) already used by another record",
            });
        }

        await db.execute(
            `UPDATE qualification SET
                certification_no = ?,
                institute_name = ?,
                completed_date = ?,
                city = ?,
                certificate_file = COALESCE(?, certificate_file)
                WHERE id = ?`,
            [certification_no,institute_name,completed_date,city,certificate,id]
        );

        return res.json({
            success: true,
            message: "Qualification updated successfully",
        });

    } catch (error) {
        console.error("Qualification Error:", error);
        if (error.code === "ER_DUP_ENTRY") {
            return res.status(409).json({
                success: false,
                message: "Duplicate Qualifications not allowed",
            });
        }
        return res.status(500).json({
            success: false,
            message: "Something went wrong",
        });
    }
};


const getQualifications = async (req, res) => {
    try {
        const db = req.db;
        const admin_id = req.user.admin_id || req.user.id;
        const employee_id = req.params.id || req.user.id;

        const [rows] = await db.execute(
            `SELECT id, certification_no, institute_name, completed_date, city, certificate_file
                FROM qualification
            WHERE admin_id = ? AND employee_id = ?`,
            [admin_id, employee_id]
        );

        res.json({
            success: true,
            data: rows,
        });

    } catch (err) {
        console.error("Get Qualification Error:", err);
        res.status(500).json({ success: false });
    }
};


const getQualificationById = async (req, res) => {
    try {
        const db = req.db;
        const admin_id = req.user.admin_id || req.user.id;
        const qualificationId = req.params.id;

        const [rows] = await db.execute(
            `SELECT id, certification_no, institute_name, completed_date, city, certificate_file
                FROM qualification
            WHERE id = ? AND admin_id = ?`,
            [qualificationId, admin_id]
        );

        res.json({
            success: true,
            data: rows[0] || null,
        });

    } catch (err) {
        console.error("Get Single Qualification Error:", err);
        res.status(500).json({ success: false });
    }
};



module.exports = {
    saveQualification,
    getQualifications,
    getQualificationById
};
