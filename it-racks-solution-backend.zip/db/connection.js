// const mysql = require('mysql2/promise');
// const dbConnection = mysql
//   .createPool({
//     host: "localhost",
//     user: "root",
//     password: "",
//     database: "it-racks-solution",
//   })

// module.exports = dbConnection;

const mysql = require('mysql2/promise');

const db = mysql.createPool({
  host: "localhost",
  user: "root",
  password: "",
  database: "it-racks-solution",
  waitForConnections: true,
  connectionLimit: 10,
});

module.exports = db;