const router = require("express").Router();
const { verifyToken } = require('../middlewares/authMiddleware')
const { SignupFunction,RefreshToken, SignInUser, signupWithCompany} = require("../controllers/SignUp/index");
const { registerCompany,GetUser,UpdateCompany, GetCompanyByAdmin } = require("../controllers/company/index")
const { CreateHardware,GetAllHardware,UpdateHardware, GetHardwareById, DeleteHardware } = require("../controllers/assets/hardware/index")
const { CreateSoftware, GetAllSoftware, GetSoftwareById, UpdateSoftware, DeleteSoftware } = require("../controllers/assets/Software/index")
const upload = require("../controllers/filemulters/projectMulter"); 
const { GetAllBrandsManufacturer, CreateBrand } = require("../controllers/Brand");
const { GetAllDepartments, CreateDepartment } = require("../controllers/Departments");
const { createTicket, GetAllTickets } = require("../controllers/tickets");
const { getAdminEmployeesPermissions, saveEmployeePermissions } = require("../controllers/permissions/index");
const {resendOtp,verifyOtp, forgotPassSentOtp, updatePassword,} = require("../controllers/Otp/index");
const { CreateRoles, GetAllRoles } = require("../controllers/roles");
const { CreateDesignation, GetAllDesignations } = require("../controllers/designations");
const { SaveTheme, GetTheme } = require("../controllers/themes");
const { GenratedEmpId, CreatePeople, GetEmpByIdSearchWithPagination, GetAllEmployeesBySimpleList, UpdatePeople, DeleteEmployees, UpdateSuperAdmin, uploadUserImage, GetSuperAdminById } = require("../controllers/People");
const { syncModules } = require("../controllers/Modules/DataSeeder");
const {checkPermission} = require("../middlewares/PermissionModule");
const tenantDbMiddleware = require("../middlewares/tenantDbMiddleware");
const { saveEducation, getEducationById, getEducationByEduId } = require("../controllers/education");
const setUploadConfig = require("../controllers/filemulters/uploadConfig");
const { saveQualification, getQualifications, getQualificationById } = require("../controllers/qualification");
const { saveExperience, getExperienceByEmployee, getExperienceById } = require("../controllers/experiance");
const { checkCompanyAccess } = require("../middlewares/companyCheck");





// ADMIN/USER ROUTES =========================
router.post('/api/signupWithCompany/User',
    setUploadConfig("company-logos",  ["image/jpeg", "image/png"]),
    upload.single('logo'),
    signupWithCompany);


router.post('/api/SignIn/User',
    SignInUser)


// COMPANY ROUTES ============================
router.get('/api/company/GetById', 
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("overview_view"),
    GetCompanyByAdmin);

router.get('/api/user/user',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    GetUser);

router.post('/api/company/UpdateCompany', 
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("overview_company_update"), 
    UpdateCompany);

// REFRESH ROUTES ===================================
router.post('/api/token/refreshToken',
    RefreshToken)


// BRAND ROUTES =======================================
router.get('/api/GetAllBrandsManufacturer',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("Brand_view"),
    GetAllBrandsManufacturer)


router.post('/api/hardware/CreateBrand',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("Brand_create"),
    CreateBrand)

// DEPARTMENTS ROUTES ==================================
router.get('/api/get/GetAllDepartments',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("department_view"),
    GetAllDepartments)


router.post('/api/hardware/CreateDepartment',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("department_create"),
    CreateDepartment)

// ROLES ROUTES ========================================
router.post('/api/createRole/ByAdmin',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("roles_create"),
    CreateRoles)

router.get('/api/GetAllRole/ByAdmin',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("roles_view"),
    GetAllRoles)


// DESIGNATIONS ROUTES ==================================
router.post('/api/createDesignation/ByAdmin',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("designation_create"),
    CreateDesignation)

router.get('/api/GetAllDesignation/ByAdmin',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("designation_view"),
    GetAllDesignations)

// HARDWARE ROUTES =====================================
router.post('/api/hardware/CreateHardware',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("hardware_create"),
    CreateHardware)

router.get('/api/hardware/GetAllHardware',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("hardware_view"),
    GetAllHardware)

router.put('/api/hardware/UpdateHardware/:id',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("hardware_update"),
    UpdateHardware)

router.get("/api/get/all/hardware/:id", 
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    GetHardwareById);

router.post('/api/Hardware/DeleteHardware',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("hardware_delete"),
    DeleteHardware);


// SOFTWARE ROUTES ========================================
router.post('/api/software/CreateSoftware',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("software_create"),
    CreateSoftware)

router.get('/api/software/getAllsoftwareByPage',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("software_view"),
    GetAllSoftware)

router.get("/api/software/all/getsoftware/:id", 
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    GetSoftwareById);

router.put('/api/software/UpdateSoftware/:id',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("software_update"),
    UpdateSoftware)

router.post('/api/Software/DeleteSoftware', 
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("software_delete"),
    DeleteSoftware);


// PARMISSIONS ROUTES FOR MAIN Super Admin =========================
router.get('/api/permissions_view/byAdmin',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    getAdminEmployeesPermissions)

router.post( "/api/permissions/save/byAdmin",
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    saveEmployeePermissions);


// THEME ROUTES ==============================================
router.post('/api/theme/saveThemeSetting',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    SaveTheme)

router.get('/api/theme/getThemeSetting',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    GetTheme)

// EMPLOYEE CRETAE ROUTES =====================================
router.get("/api/emp-next-id",
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    GenratedEmpId);

router.post("/api/emp/create-emp",
    verifyToken, 
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("people_create"),
    CreatePeople);


// router.post("/api/create/create-super-admin",
//     verifyToken, 
//     tenantDbMiddleware,
//     // checkCompanyAccess,
//     // checkPermission("people_create"),
//     CreateSuperAdmin);
//     // CreateSuperAdmin
// //  checkPermission("people_update")


router.post('/api/profile/Image',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    setUploadConfig("profile-images",  ["image/jpeg", "image/png","image/jpg"]),
    upload.single('image'),
    uploadUserImage)

router.put("/api/updateEmp/:id", 
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    UpdatePeople);

router.put("/api/UpdateSuperAdmin/:id", 
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    UpdateSuperAdmin);

router.post('/api/DeleteEmp', 
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("people_delete"),
    DeleteEmployees);

router.get('/api/GetEmpByIdSearchWithPagination',
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    checkPermission("people_view"),
    GetEmpByIdSearchWithPagination)

// router.get("/api/Emp/:id", 
//     verifyToken,
//     tenantDbMiddleware,
//     // checkCompanyAccess,
//     GetEmployeeById);


router.get("/api/GetSuperAdminById", 
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    GetSuperAdminById);

router.get("/api/GetAllEmployeesBySimpleList",
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    GetAllEmployeesBySimpleList);



// EDUCATIONS CREATE ROUTES =======================
router.post("/api/edu/addEducation",
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    setUploadConfig("edu_certificates", ["application/pdf"]),
    upload.single('file'),
    saveEducation);


router.get("/api/get/education/:id",
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    getEducationById);

router.get("/api/get/educationByid/:id",
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    getEducationByEduId);


// QUALIFICATION CREATE ROUTES =======================
router.post("/api/qua/addQualification",
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    setUploadConfig("qua_certificates", ["application/pdf"]),
    upload.single('file'),
    saveQualification);

router.get("/api/get/qualification/:id",
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    getQualifications);

router.get("/api/get/qualificationById/:id",
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    getQualificationById);



// EXPERIANCE CREATE ROUTES =======================
router.post("/api/exper/addExperiance",
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    setUploadConfig("experience_docs", ["application/pdf"]),
    upload.single('file'),
    saveExperience);

router.get("/api/get/Experiance/:id",
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    getExperienceByEmployee);



router.get("/api/get/ExperianceById/:id",
    verifyToken,
    tenantDbMiddleware,
    // checkCompanyAccess,
    getExperienceById);





// PERMISSION MODULES SET ROUTES FOR DEVELOPER ===================================
router.post("/api/system/sync-modules",syncModules);


// ADMIN/USER OTP ROUTES ============================
router.post('/api/resendOtp/User', tenantDbMiddleware,resendOtp);
router.post('/api/verifyOtp/User', tenantDbMiddleware,verifyOtp);


// ADMIN/USER FORGOT PASSWORDS ROUTES =======================
router.post("/api/password/forgotPassword",tenantDbMiddleware, forgotPassSentOtp)
router.post("/api/password/updatePassword",tenantDbMiddleware, updatePassword)





// router.post('/api/Tickets/createTicket', verifyToken, createTicket);
// router.get('/api/Tickets/GetAllTickets', verifyToken, GetAllTickets);




module.exports = router;